<?php $__env->startSection('section-1'); ?>
        <section class="mx-auto mt-5 shadow p-3 just container">
            <?php echo Form::open(['action' => '\App\Http\Controllers\factureController@search', 'method'=>'GET']); ?>

                <div class="d-lg-flex w-100 justify-content-around">
                    <div class="mb-3 col-lg-3">
                        <label for="date_dep" class="form-label">De</label>
                        <input type="date" class="form-control" name="date_dep" value="<?php echo date('Y-m-d') ?>">
                    </div>
                    <div class="mb-3 col-lg-3">
                        <label for="date_art" class="form-label">à</label>
                        <input type="date" class="form-control"  name="date_art" value="<?php echo date('Y-m-d') ?>">
                    </div>
                    <div class="mb-3 col-lg-3">
                        <label for="exampleInputPassword1" class="form-label">Batiement</label>
                        <select name="batiment" class="form-control" id="">
                            <option value="">Tout</option>
                            <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="text-center">
                    <a href="#"><button type="submit" class="btn border-success text-success btn-edit">Afficher</button></a>
                    <a href="/facture" class="btn border-secondary">Afficher tout</a>
                    <a href="/facture/create" class="btn border-primary text-primary btn-add">Ajouter</a>
                </div>
            <?php echo Form::close(); ?>

        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container-xl container-lg shadow mt-4">
        <?php if(count($facture)>0): ?>
            <table class="table table-striped">
                <tr>
                    <th>id</th>
                    <th>Type facture</th>
                    <th>Reference</th>
                    <th>Date d'ajoute</th>
                    <th>Montant</th>
                    <th>Batiment</th>
                    <th class="text-center">Action</th>
                </tr>
                <?php $__currentLoopData = $facture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($fac->id); ?></td>
                        <td><?php echo e($fac->type_facture); ?></td>
                        <td><?php echo e($fac->reference_facture); ?></td>
                        <td><?php echo e($fac->date_dep); ?></td>
                        <td><?php echo e($fac->montant); ?></td>
                        <td><?php echo e($fac->batiment); ?></td>
                        <td class="text-center d-md-block d-sm-block d-lg-block">
                            <a href="/facture/<?php echo e($fac->id); ?>" class="btn btn-consult border-primary text-primary"><i class="bi bi-eye"></i></a>
                            <a href="/facture/<?php echo e($fac->id); ?>/edit"><button class="btn btn-edit border-success text-success"><i class="bi bi-pencil-square"></i></button></a>
                            <a href="#" data-id="<?php echo e($fac->id); ?>" class="deletebtn"><button class="btn btn-delete border-danger text-danger"><i class="bi bi-trash3"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
    <script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>
        $('.deletebtn').click(function (){
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vou vraiment supprimer "+id,
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/facture/delete/"+id;
                    }
                });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/facture/facture.blade.php ENDPATH**/ ?>