<?php $__env->startSection('section-1'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>