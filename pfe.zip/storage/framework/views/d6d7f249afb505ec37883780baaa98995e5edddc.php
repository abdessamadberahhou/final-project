<?php $__env->startSection('section-1'); ?>
  <div class="container choice_field shadow mt-5">
      <div class="row">
          <div class="col-12 text-center p-4">
              <a href="#" class="btn border-primary text-primary">Lister les factures</a>
              <a href="#" class="btn border-success text-success">Payer les factures</a>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container shadow list_payment-bills mt-5">
        <table class="table">
            <tr>
                <th>Id</th>
                <th>CIN</th>
                <th>Ref de facture</th>
                <th>Date de payment</th>
                <th>Num de reçu</th>
                <th>Statut</th>
                <th class="text-center">Action</th>
            </tr>
            <?php $__currentLoopData = $facture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($fact->Id_res); ?></td>
                    <td><?php echo e($fact->CIN_res); ?></td>
                    <td><?php echo e($fact->reference_facture); ?></td>
                    <td><?php echo e($fact->date_payment); ?></td>
                    <td><?php echo e($fact->num_recu); ?></td>
                    <td><?php echo e($fact->statut); ?></td>
                    <td class="text-center">
                        <a href="/payment/resident/<?php echo e($fact->id); ?>" class="btn btn-consult border-primary text-primary"><i class="bi bi-eye"></i></a>
                        <a href="#" class="btn btn-edit border-success text-success"><i class="bi bi-pencil-square"></i></a>
                        <a href="#" class="btn btn-delete border-danger text-danger"><i class="bi bi-trash3"></i></a>
                        <a href="#" class="btn border-info text-info"><i class="bi bi-cash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-3'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/payment/resident/facture_payment.blade.php ENDPATH**/ ?>
