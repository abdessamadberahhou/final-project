<?php $__env->startSection('section-1'); ?>
    <div class="container mt-5 shadow">
        <h><?php echo e(__('Billing')); ?></h>
        <table class="table">
            <tr>
                <th>Tes1</th>
                <th>Tes1</th>
                <th>Tes1</th>
            </tr>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($invoices->date()->toFormattedDateString()); ?></td>
                    <td><?php echo e($invoices->title->total()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/payment/operateur/operateur_payment.blade.php ENDPATH**/ ?>