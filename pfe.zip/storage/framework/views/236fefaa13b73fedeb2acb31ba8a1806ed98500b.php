<?php if(!Auth::user()): ?>
<nav class="navbar navbar-expand-md bg-white shadow-sm">
    <div class="container">

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="navbar-nav ms-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>

                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pfe\resources\views/navbar/navbar.blade.php ENDPATH**/ ?>