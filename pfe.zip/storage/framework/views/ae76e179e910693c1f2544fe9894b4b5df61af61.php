<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalerts.js')); ?>"></script>
<?php if(count($errors)>0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <script style="white-space: break-spaces">
                swal ( "Erreur" ,  "<?php echo e($error); ?>" ,  "error" );
            </script>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
        <div>
            <script style="white-space: break-spaces">
                swal("<?php echo e(session('success')); ?>", "", "success");
            </script>
        </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div>
        <script style="white-space: break-spaces">
            swal("<?php echo e(session('error')); ?>", "", "error");
        </script>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pfe\resources\views/inc/messages.blade.php ENDPATH**/ ?>