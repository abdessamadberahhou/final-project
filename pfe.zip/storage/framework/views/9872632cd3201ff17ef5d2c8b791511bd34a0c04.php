<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 p-5 rounded-2">
        <?php if($ope!=null): ?>
            <div class="all pt-5">
                <div class="row text-center mb-5">
                    <h2><b>Information sur l'opérateur</b></h2>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Nom <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->nom_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Prénom <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->prenom_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Date de naissance <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->date_nai_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Date d'embauche <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->date_emb_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">CIN <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->cin_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Numéro de téléphone <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->num_tele_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Type opérateur <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->type_ope); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Salaire <span>:</span> </dt>
                        <dd class="col"><?php echo e($ope->salaire); ?> MAD</dd>
                    </dl>
                </div>
                <div class="retour text-center">
                    <a href="/operateur" class="btn border-primary text-primary btn-add">Retour</a>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center">
                <h1>Aucun resultat</h1>
            </div>
            <div class="retour text-center">
                <a href="/operateur" class="btn border-primary text-primary btn-add">Retour</a>
            </div>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container shadow mt-5">
        <table class="table">
            <tr>
                <th><b>Mois</b></th>
                <th class="month text-center">JANVIER</th>
                <th class="month text-center">FÉVRIER</th>
                <th class="month text-center">MARS</th>
                <th class="month text-center">AVRIL</th>
                <th class="month text-center">MAI</th>
                <th class="month text-center">JUIN</th>
                <th class="month text-center">JUILLET</th>
                <th class="month text-center">AOÛT</th>
                <th class="month text-center">SEPTEMBRE</th>
                <th class="month text-center">OCTOBRE</th>
                <th class="month text-center">NOVEMBRE</th>
                <th class="month text-center">DÉCEMBRE</th>
            </tr>
            <tr>
                <td><b>Statut</b></td>
                <td class="statut text-center"><?php echo e($jan); ?></td>
                <td class="statut text-center"><?php echo e($feb); ?></td>
                <td class="statut text-center"><?php echo e($mar); ?></td>
                <td class="statut text-center"><?php echo e($apr); ?></td>
                <td class="statut text-center"><?php echo e($may); ?></td>
                <td class="statut text-center"><?php echo e($jun); ?></td>
                <td class="statut text-center"><?php echo e($jul); ?></td>
                <td class="statut text-center"><?php echo e($aug); ?></td>
                <td class="statut text-center"><?php echo e($sep); ?></td>
                <td class="statut text-center"><?php echo e($oct); ?></td>
                <td class="statut text-center"><?php echo e($nov); ?></td>
                <td class="statut text-center"><?php echo e($dec); ?></td>
            </tr>
        </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
            <script>
                let month = document.getElementsByClassName('month');
                for(let i=0;i<month.length;i++){
                    month[i].style.color = 'darkgray';
                }
                let statut = document.getElementsByClassName('statut')
                for(let i=0;i<statut.length;i++){
                    if(statut[i].innerHTML.toString() == 'payé'){
                        statut[i].style.fontWeight = 'bold';
                        statut[i].style.color = '#0cf510';
                    }
                    else if(statut[i].innerHTML == 'non payé'){
                        statut[i].style.color = '#f5200c';
                        statut[i].style.fontWeight = 'bold';
                    }
                }
            </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/operateur/show.blade.php ENDPATH**/ ?>