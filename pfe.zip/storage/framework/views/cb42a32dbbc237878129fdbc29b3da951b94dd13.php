<?php $__env->startSection('section-1'); ?>
    <div class="container shadow mt-5 p-5">
        <?php echo Form::open(['action'=>['\App\Http\Controllers\ameliorationController@update',$amelioration->id_amel],'method'=>'post']); ?>

        <div class="row justify-content-around text-center">
            <div class="col-lg-4">
                <label for="type_amel" class="form-label">Type amelioration</label>
                <select class="form-control" name="type_amel" >
                    <?php $__currentLoopData = $all_amel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if("<?php echo e($amelioration->type_amel); ?>" == "<?php echo e($amel->type_amel); ?>"): ?>
                            selected="selected"
                            <?php endif; ?>
                            value="<?php echo e($amel->type_amel); ?>"><?php echo e($amel->type_amel); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-lg-4">
                <label for="nom_bat" class="form-label">Batiment</label>
                <select class="form-control" name="batiment" >
                    <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if("<?php echo e($amelioration->batiment_amel); ?>" == "<?php echo e($bat->nom_bat); ?>"): ?>
                            selected="selected"
                            <?php endif; ?>
                            value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-lg-4">
                <label for="type_amel" class="form-label">Date d'amelioration</label>
                <input type="date" class="form-control" name="date_ameli" value="<?php echo e($amelioration->date_ameli); ?>">
            </div>
            <div class="col-lg-4">
                <label for="montant" class="form-label">Montant</label>
                <input type="text" class="form-control" name="montant" value="<?php echo e($amelioration->montant_amel); ?>">
            </div>
        </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-lg-4">
                <label for="description" class="form-label">Description</label>
                <textarea type="text" class="form-control" name="description"><?php echo e($amelioration->description_amel); ?></textarea>
            </div>
            <div class="col-lg-4"></div>
        </div>
        <?php echo Form::hidden('_method','PUT'); ?>

        <div class="row justify-content-around text-center mt-4">
            <div class="col-6">
                <button class="btn border-success text-success" type="submit">Modifier</button>
                <a href="/amelioration" class="btn border-primary text-primary">Retour</a>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/amel/edit.blade.php ENDPATH**/ ?>