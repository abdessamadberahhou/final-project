<div class="sidebar close">
    <div class="logo-details">
        <span class="logo_name">Sclean</span>
        <i class="fal fa-bars btnMenu bx bx-menu"></i>
    </div>
    <ul class="nav-links">
        <li>
            <a href="dashboard.php">
                <i class="fas fa-home-lg"></i>
                <span class="link_name">Dashboard</span>
            </a>
            <ul class="sub-menu blank">
                <li>
                    <a class="link_name" href="dashboard.php">Dashboard</a>
                </li>
            </ul>
        </li>
        <li>
            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-users" id="icon-p1"></i>
                    <span class="link_name">Residents</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow1" onclick="openMenu('box1','arrow1');"></i>
            </div>
            <ul class="sub-menu" id="box1">
                <li><a class="link_name" href="#">Residents</a></li>
                <li><a href="/resident/create">Ajouter un resident</a></li>
                <li><a href="/resident">Consulter les residents</a></li>
            </ul>
        </li>
        <li>
            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-file-invoice-dollar " id="icon-p2"></i>
                    <span class="link_name">Factures</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow2" onclick="openMenu('box2','arrow2');"></i>
            </div>
            <ul class="sub-menu" id="box2">
                <li><a class="link_name" href="#">Factures</a></li>
                <li><a href="/facture/create">Ajouter une facture</a></li>
                <li><a href="/facture">Consulter une facture</a></li>
            </ul>
        </li>
        <li>
            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-building" id="icon-p3"></i>
                    <span class="link_name">Bâtiments</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow3" onclick="openMenu('box3','arrow3')"></i>
            </div>
            <ul class="sub-menu" id="box3">
                <li><a class="link_name" href="#">Bâtiments</a></li>
                <li><a href="/batiment/create">Ajouter une Bâtiment</a></li>
                <li><a href="/batiment">Consulter une Bâtiments</a></li>
            </ul>
        </li>
        <li>
            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-user-hard-hat icon-p"></i>
                    <span class="link_name">Operateurs</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow4" onclick="openMenu('box4','arrow4')"></i>
            </div>
            <ul class="sub-menu" id="box4">
                <li><a class="link_name" href="#">Operateurs</a></li>
                <li><a href="/operateur/create">Ajouter un operateur</a></li>
                <li><a href="/operateur">Consulter les operateurs</a></li>
            </ul>
        </li>
        <li>
            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-upload"></i>
                    <span class="link_name">Ameliorations</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow5" onclick="openMenu('box5','arrow5')"></i>
            </div>
            <ul class="sub-menu" id="box5">
                <li><a class="link_name" href="#">Ameliorations</a></li>
                <li><a href="/amelioration/create">Ajouter une amel</a></li>
                <li><a href="/amelioration">Consulter les amels</a></li>
            </ul>
        </li>
        <li>

            <div class="iocn-link">
                <a href="#">
                    <i class="fas fa-usd-circle"></i>
                    <span class="link_name">Paiments</span>
                </a>
                <i class="fas fa-caret-right arrow" id="arrow6" onclick="openMenu('box6','arrow6')"></i>
            </div>
            <ul class="sub-menu" id="box6">
                <li><a class="link_name" href="#">Paiments</a></li>
                <li><a href="#">Resident</a></li>
                <li><a href="#">Facture</a></li>
                <li><a href="#">Operateur</a></li>
                <li><a href="#">Ameliorations</a></li>
            </ul>
        </li>
    </ul>
</div>
<script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/sidebar/sidebar.blade.php ENDPATH**/ ?>