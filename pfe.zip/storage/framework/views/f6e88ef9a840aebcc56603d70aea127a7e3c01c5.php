<?php $__env->startSection('section-1'); ?>
    <!--<section class="container mx-auto mt-5 shadow p-3 just">
        <?php echo Form::open(['action' => '\App\Http\Controllers\residentController@search', 'method'=>'GET']); ?>

        <div class="d-lg-flex w-100  justify-content-between text-center ">
            <div class="mb-3 col-3 col-md-8 col-sm-6 col-lg-3 mx-auto">
                <label for="nom" class="form-label">Nom</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="nom">
            </div>
            <div class="mb-3 col-3 col-md-8 col-sm-6 col-lg-3 mx-auto">
                <label for="CIN" class="form-label">CIN</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="CIN">
            </div>
            <div class="mb-3 col-3 col-md-8  col-sm-6 col-lg-3 mx-auto">
                <label for="exampleInputPassword1" class="form-label">Batiement</label>
                <select name="batiment" class="form-select" id="">

    
    
        </select>
    </div>
</div>
<div class="text-center">
    <button type="submit" class="btn btn-success">Afficher</button>
    <a href="/resident/create" class="btn btn-primary">Ajouter</a>
</div>
<?php echo Form::close(); ?>

        </section>-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <?php if(count($resident)>0): ?>
        <div class=" container-xl container-xxl mt-5 shadow">
            <table class="table text-center" id="datatable">
                <tr>
                <?php echo Form::open(['action' => '\App\Http\Controllers\residentController@search', 'method'=>'GET']); ?>

                <tr>
                    <th class="col-lg-1">
                        <input type="text" class="form-control text-center filter-input" name="id"
                               placeholder="id" data-column="0">
                    </th>
                    <th class="col-lg-2">
                        <input type="text" class="form-control text-center filter-input" name="prenom"
                               placeholder="prenom" data-column="1">
                    </th>
                    <th class="col-lg-2">
                        <input type="text" class="form-control text-center filter-input" name="nom"
                               placeholder="nom" data-column="2">
                    </th>
                    <th>

                    </th>
                    <th class="col-lg-1">
                        <input type="text" class="form-control text-center filter-input" name="CIN"
                               placeholder="CIN" data-column="3">
                    </th>
                    <th>

                    </th>
                    <th>

                    </th>
                    <th class="col-lg-1">
                        <select name="batiment" class="form-select filter-input1" id="" data-column="4">
                            <option value="">Tout</option>
                            <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </th>
                    <th>
                        <button type="submit" class="btn btn-success">Afficher</button>
                    </th>
                </tr>
                <?php echo Form::close(); ?>

                <tr>
                    <th>Id</th>
                    <th>Prenom</th>
                    <th>Nom</th>
                    <th>Date nais</th>
                    <th>CIN</th>
                    <th>Num tele</th>
                    <th>Nb pers</th>
                    <th>Adresse</th>
                    <th class="text-center">Action</th>
                </tr>
                </tr>
                <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($res->Id_resident); ?></td>
                        <td><a href="/resident/<?php echo e($res->Id_resident); ?>"><?php echo e($res->Prenom); ?></a></td>
                        <td><?php echo e($res->Nom); ?></td>
                        <td><?php echo e($res->Date_nai); ?></td>
                        <td><?php echo e($res->CIN); ?></td>
                        <td><?php echo e($res->num_tele); ?></td>
                        <td><?php echo e($res->nb_pers); ?></td>
                        <td><?php echo e($res->adresse); ?></td>
                        <td class="text-center">
                            <a href="/resident/<?php echo e($res->Id_resident); ?>/edit" class="btn btn-edit border-success text-success"><i class="bi bi-pencil-square"></i></a>
                            <a class="btn-delete btn border-danger text-danger" data-name="<?php echo e($res->Prenom); ?>" data-id="<?php echo e($res->Id_resident); ?>" href="#"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tf>

                </tf>
            </table>
        </div>
    <?php endif; ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>

        $('.deletebtn').click(function (){
            var name = $(this).attr('data-name');
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vou vraiment supprimer "+name,
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/resident/delete/"+id;
                    }
                });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/resident/search.blade.php ENDPATH**/ ?>