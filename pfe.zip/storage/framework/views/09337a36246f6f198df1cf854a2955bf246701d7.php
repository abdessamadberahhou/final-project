<?php $__env->startSection('section-2'); ?>
    <div class="container shadow list_container list_payment-bills mt-5" id="list_container">
        <table class="table">
            <tr>
                <th>Id</th>
                <th>Ref de facture</th>
                <th>Date de payment</th>
                <th>Num de reçu</th>
                <th>Statut</th>
                <th class="text-center">Action</th>
            </tr>
            <?php $__currentLoopData = $facture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($fact->Id_res); ?></td>
                    <td><?php echo e($fact->reference_facture); ?></td>
                    <td><?php echo e($fact->date_payment); ?></td>
                    <td><?php echo e($fact->num_recu); ?></td>
                    <td><?php echo e($fact->statut); ?></td>
                    <td class="text-center">
                        <a href="/payment/facture/<?php echo e($fact->id); ?>" class="btn btn-consult border-primary text-primary"><i class="bi bi-eye"></i></a>
                        <a href="/payment/facture/<?php echo e($fact->id); ?>/edit" class="btn btn-edit border-success text-success"><i class="bi bi-pencil-square"></i></a>
                        <a href="#" class="btn deletebtn btn-delete border-danger text-danger" data-id="<?php echo e($fact->id); ?>"><i class="bi bi-trash3"></i></a>
                        <a href="/pay/<?php echo e($fact->id); ?>/checkout" class="btn border-info text-info"
                            <?php if($fact->statut == 'payé'): ?>
                                hidden
                            <?php endif; ?>
                        ><i class="bi bi-cash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>
        // $('.deletebtn').click(function (){
        //     var id = $(this).attr('data-id');
        //     swal({
        //         title: "voulez vou vraiment supprimer "+id,
        //         text: "",
        //         icon: "warning",
        //         buttons: true,
        //         dangerMode: true,
        //     })
        //         .then((willDelete) => {
        //             if (willDelete) {
        //                 window.location = "/payment/facture/delete/"+id;
        //             }
        //         });
        // });
        // listbtn = document.querySelector('.list-btn');
        // cont = document.getElementById('list_container');
        // $('.list-btn').click(function (){
        //     cont.togglle(400);
        // });
        // $(document).ready(function (){
        //     $('.list-btn').click(function(){
        //         $('.list_container').slideToggle(700);
        //     })
        // })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-3'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/payment/facture/facture_payment.blade.php ENDPATH**/ ?>