<?php $__env->startSection('section-1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container-xl container-lg shadow mt-5">
        <table class="table table-striped">
            <tr>
                <?php echo Form::open(['action' => '\App\Http\Controllers\factureController@search', 'method'=>'GET']); ?>

                <th class="col-1">
                    <input type="text" name="id" id="" class="form-control text-center" placeholder="id">
                </th>
                <th class="col-2">
                    <select name="type_fact" id="type_fact" class="form-control text-center">
                        <option value="">Choisir votre type</option>
                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type_f->valeur_type); ?>"><?php echo e($type_f->valeur_type); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </th>
                <th class="col-2">
                    <input type="text" name="reference" id="" class="form-control text-center" placeholder="réference">
                </th>
                <th>
                    <select name="month" id="month" class="form-control text-center">
                        <option value="">Tout</option>
                        <option value="1">Janvier</option>
                        <option value="2">Fevrier</option>
                        <option value="3">Mars</option>
                        <option value="4">April</option>
                        <option value="5">Mai</option>
                        <option value="6">June</option>
                        <option value="7">Juillet</option>
                        <option value="8">Aout</option>
                        <option value="9">Septembre</option>
                        <option value="10">Octobre</option>
                        <option value="11">Nouvembre</option>
                        <option value="12">Decembre</option>
                    </select>
                </th>
                <th class="col-1">
                    <input type="text" name="id_res" id="id_res" class="form-control text-center" placeholder="Res">
                </th>
                <th>
                    <select name="batiment" class="form-control text-center" id="">
                        <option value="">Tout</option>
                        <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </th>
                <th></th>
                <th class="text-center">
                    <button class="btn text-success border-success btn-edit">Rechercher</button>
                    <a href="/facture/create" class="btn border-primary text-primary btn-add">Ajouter</a>
                    <a href="generate/facture" class="btn btn-secondary">generate</a>
                </th>
                <?php echo Form::close(); ?>

            </tr>
            <tr>
                <th class="text-center">id</th>
                <th class="text-center">Type facture</th>
                <th class="text-center">Reference</th>
                <th class="text-center">Date d'ajout</th>
                <th class="text-center">Id res</th>
                <th class="text-center">Batiment</th>
                <th class="text-center">Staut</th>
                <th class="text-center">Action</th>
            </tr>
            <?php if(count($facture)>0): ?>
                <?php $__currentLoopData = $facture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($fac->id); ?></td>
                        <td class="text-center"><?php echo e($fac->type_facture); ?></td>
                        <td class="text-center text-nowrap"><?php echo e($fac->reference_facture); ?></td>
                        <td class="text-center"><?php echo e($fac->date_ajout); ?></td>
                        <td class="text-center"><?php echo e($fac->Id_res); ?></td>
                        <td class="text-center"><?php echo e($fac->batiment); ?></td>
                        <td class="text-center"><?php echo e($fac->statut); ?></td>
                        <td class="text-center">
                            <?php echo Form::open(['action'=>['\App\Http\Controllers\factureController@pay',$fac->id],'method'=>'GET']); ?>

                            <a href="/facture/<?php echo e($fac->id); ?>" class="btn btn-consult border-primary text-primary"><i class="bi bi-eye"></i></a>
                            <a  class="btn btn-edit border-success text-success" href="/facture/<?php echo e($fac->id); ?>/edit"><i class="bi bi-pencil-square"></i></a>
                            <a href="#" data-id="<?php echo e($fac->id); ?>" class="deletebtn btn btn-delete border-danger text-danger"><i class="bi bi-trash3"></i></a>

                            <?php if($fac->statut != 'payé'): ?>
                                <button class="btn border-info text-info"<?php if($fac->statut == 'payé'): ?>
                                hidden
                                    <?php endif; ?>>
                                    <i class="bi bi-cash"></i>
                                </button>
                            <?php endif; ?>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="paginate text-center">
            <?php echo e($facture->links()); ?>

        </div>
        <?php else: ?>
        </table>
            <div class="no_records text-center">
                <h4><b>Aucun resultat</b></h4>
            </div>
        <?php endif; ?>

    </div>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>
        $('.deletebtn').click(function (){
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vous vraiment supprimer cette facture",
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/facture/delete/"+id;
                    }
                });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/facture/search.blade.php ENDPATH**/ ?>