
<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 py-3">
        <?php if($fac!=null): ?>
            <?php echo Form::open([ 'method'=>'POST', 'class'=>'form col-12']); ?>

            <div class="mx-auto w-100">
                <div class="row field-add_resident d-lg-felx d-md-flex">
                    <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center t-sm-1 text-xs-center">
                        <label for="type_facture" class="form-label">Type de facture</label>
                        <input type="text" class="form-control w-75 mx-auto" name="type_facture" value="<?php echo e($fac->type_facture); ?>" disabled>
                    </div>
                    <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label for="reference" class="form-label" >Reference</label>
                        <input type="text" class="form-control w-75 mx-auto" name="reference" value="<?php echo e($fac->reference_facture); ?>" disabled>
                    </div>
                </div>
                <div class="row field-add_resident d-lg-felx pt-lg-3 d-md-flex">
                    <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="date_ajout">Date d'ajoute</label>
                        <input type="date" class="form-control w-75 mx-auto" name="date_ajoute" value="<?php echo e($fac->date_dep); ?>" disabled>
                    </div>
                    <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="montant">Montant</label>
                        <input type="text" class="form-control w-75 mx-auto" name="montant" value="<?php echo e($fac->montant); ?>" disabled>
                    </div>
                </div>
                <div class="row field-add_resident d-lg-felx pt-lg-3">
                    <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="batiment">Batiment</label>
                        <input type="text" class="form-control w-75 mx-auto" name="batiment" value="<?php echo e($fac->batiment); ?>" disabled>
                    </div>

                <div class="row field-add_resident mt-4">
                    <div class="col-12 col-add_resident col-resident1 pt-sm-3 text-center">
                        <a href="/facture" class="text-primary btn border-primary">Retour</a>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        <?php else: ?>
            <h1>aucun facture avec cette id</h1>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/facture/show.blade.php ENDPATH**/ ?>