<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 p-5 rounded-2">
        <?php if($rs!=null): ?>
        <?php echo Form::open(['action' => ['\App\Http\Controllers\residentController@update', $rs->Id_resident], 'method'=>'POST', 'class'=>'form col-12']); ?>

        
        <div class="mx-auto w-100">
            <div class="row field-add_resident d-lg-felx d-md-flex">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center t-sm-1 text-xs-center">
                    <label for="nom" class="form-label">Nom</label>
                    <input type="text" class="form-control w-75 mx-auto" name="nom" value="<?php echo e($rs->Nom); ?>">
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label for="prenom" class="form-label" >Prénom</label>
                    <input type="text" class="form-control w-75 mx-auto" name="prenom" value="<?php echo e($rs->Prenom); ?>">
                </div>
            </div>
            <div class="row field-add_resident d-lg-felx pt-lg-3 d-md-flex">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center" >
                    <label class="form-label" for="date_nai">Date de naissance</label>
                    <input type="date" class="form-control w-75 mx-auto" name="date_nai" value="<?php echo e($rs->Date_nai); ?>">
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="cin">CIN</label>
                    <input type="text" class="form-control w-75 mx-auto" name="CIN" value="<?php echo e($rs->CIN); ?>">
                </div>
            </div>
            <div class="row field-add_resident d-lg-felx pt-lg-3">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="num_tele">Numéro de Téléphone</label>
                    <input type="text" class="form-control w-75 mx-auto" name="num_tele" value="<?php echo e($rs->num_tele); ?>">
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="nb_pers">Nombre des personnes</label>
                    <input type="text" class="form-control w-75 mx-auto" name="nb_pers" value="<?php echo e($rs->nb_pers); ?>">
                </div>
            </div>
            <div class="row field-add_resident pt-lg-3">
                <div class="col-6 col-lg-6 col-add_resident col-resident1 ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="adresse">Adresse</label>
                    <select class="form-select w-75 mx-auto" name="adresse">
                        <?php if(count($bat)>0): ?>
                            <?php $__currentLoopData = $bat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                <?php if("<?php echo e($rs->adresse); ?>" == "<?php echo e($batiment->nom_bat); ?>"): ?>
                                    selected="selected"
                                <?php endif; ?>
                                value="<?php echo e($batiment->nom_bat); ?>"><?php echo e($batiment->nom_bat); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-lg-6 col-add_resident col-resident1 ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="montant_a_payer">Montant</label>
                    <input type="text" name="montant_a_payer" id="montant_a_payer" class="montant_a_payer form-control w-75 mx-auto" value="<?php echo e($rs->montant_a_payer); ?>">
                </div>
            </div>
            <?php echo Form::hidden('_method','PUT'); ?>

            <div class="row field-add_resident mt-4">
                <div class="col-12 col-add_resident col-resident1 pt-sm-3 text-center">
                    <button class="btn border-success text-success" type="submit" name="submit">Modifier</button>
                    <button class="btn border-primary"><a href="/resident" class="text-primary">Retour</a></button>
                </div>
            </div>
        </div>
        
        <?php echo Form::close(); ?>

        <?php else: ?>
        <div class="no_record text-center">
             <h1>Aucun resultat</h1>
        </div>
    </section>
        <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/resident/edit.blade.php ENDPATH**/ ?>