<?php $__env->startSection('section-1'); ?>
    <!--<div class="container shadow p-4 mt-5">

        <div class="mx-auto w-100">
            <div class="row d-lg-flex">
                <div class="col-12  col-lg-6 ps-lg-5 text-center">
                    <label for="prenom_ope" class="form-label">Prenom operateur</label>
                    <input type="text" class="form-control w-75 mx-auto" name="prenom_ope">
                </div>
                <div class="col-12 col-lg-6 ps-lg-5 text-center">
                    <label for="cin_ope" class="form-label">CIN operateur</label>
                    <input type="text" class="form-control w-75 mx-auto" name="cin_ope">
                </div>
            </div>
            <div class="row d-lg-flex mt-4">
                <div class="col-12 text-center">
                    <button class="btn border-success text-success" type="submit">Rechercher</button>
                    <a href="/operateur/create" class="btn border-primary text-primary">Ajouter</a>
                </div>
            </div>
        </div>

    </div>-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container shadow mt-5">
        <table class="table">
            <?php echo Form::open(['action' => '\App\Http\Controllers\operatorController@search', 'method'=>'GET']); ?>

            <tr>
                <th class="col-lg-1">
                    <input type="text" class="form-control text-center filter-input" name="id"
                           placeholder="id" data-column="0">
                </th>
                <th>

                </th>
                <th class="col-lg-2">
                    <input type="text" class="form-control text-center filter-input" name="nom_ope"
                           placeholder="nom ope" data-column="2">
                </th>
                <th>

                </th>
                <th>

                </th>
                <th>

                </th>
                <th>

                </th>
                <th class="col-lg-1">
                    <select name="type_ope" id="" class="form-select">
                        <option value="">Tout</option>
                        <?php $__currentLoopData = $type_ope; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->type_ope); ?>"><?php echo e($type->type_ope); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </th>
                <th>

                </th>
                <th class="text-center">
                    <button type="submit" class="btn btn-success">Afficher</button>
                </th>
            </tr>
            <?php echo Form::close(); ?>

            <tr>
                <th>id</th>
                <th>Prenom</th>
                <th>Nom</th>
                <th>CIN</th>
                <th>Date de nai</th>
                <th>Date d'aumboche</th>
                <th>Num tele</th>
                <th>Type Ope</th>
                <th>Salaire</th>
                <th>Action</th>
            </tr>
            <?php if(count($operateur)>0): ?>
                <?php $__currentLoopData = $operateur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ope->id); ?></td>
                        <td><a href="/operateur/<?php echo e($ope->id); ?>"><?php echo e($ope->prenom_ope); ?></a></td>
                        <td><?php echo e($ope->nom_ope); ?></td>
                        <td><?php echo e($ope->cin_ope); ?></td>
                        <td><?php echo e($ope->date_nai_ope); ?></td>
                        <td><?php echo e($ope->date_emb_ope); ?></td>
                        <td><?php echo e($ope->num_tele_ope); ?></td>
                        <td><?php echo e($ope->type_ope); ?></td>
                        <td><?php echo e($ope->salaire); ?></td>
                        <td>
                            <a href="/operateur/<?php echo e($ope->id); ?>/edit" class="btn border-success text-success btn-edit"><i class="bi bi-pencil-square"></i></a>
                            <a href="#" class="btn border-danger text-danger btn-delete" data-id="<?php echo e($ope->prenom_ope); ?>"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>Aucun operateur</tr>
            <?php endif; ?>
        </table>

    </div>
    <div class="text-center mt-2">
        <?php echo e($operateur->links()); ?>

    </div>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>

        $('.deletebtn').click(function (){
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vou vraiment supprimer "+id,
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/operateur/delete/"+id;
                    }
                });
        });

    </script>
    <style>
        .w-5{
            width: 1rem;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/operateur/search.blade.php ENDPATH**/ ?>