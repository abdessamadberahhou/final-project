<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/invoice.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-1'); ?>
    <div class="container">
        <div class="container">
            <div class="row">
                <div class="shadow col-md-7 col-md-offset-3 body-main mx-auto mt-4">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-4"> <i class="fa-solid fa-building display-1"></i> </div>
                        </div> <br />
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h2>Facture</h2>
                                <h5><?php echo e($facture->id); ?></h5>
                            </div>
                        </div> <br />
                        <div>
                            <table class="table text-nowrap">
                                <thead>
                                <tr>
                                    <th>
                                        <h5>Description</h5>
                                    </th>
                                    <th>
                                        <h5>Detail</h5>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="col-md-9">Type de facture</td>
                                    <td class="col-md-3"><?php echo e($facture->type_facture); ?></td>
                                </tr>
                                <tr>
                                    <td class="col-md-9">Réference de Facture</td>
                                    <td class="col-md-3"><?php echo e($facture->reference_facture); ?></td>
                                </tr>
                                <tr>
                                    <td class="col-md-9">Date d'ajout</td>
                                    <td class="col-md-3"><?php echo e($facture->date_ajout); ?> </td>
                                </tr>
                                <tr>
                                    <td class="col-md-9">Batiment</td>
                                    <td class="col-md-3"><?php echo e($facture->batiment); ?></td>
                                </tr>
                                <tr>
                                    <td class="col-md-9">Statut</td>
                                    <td class="col-md-3"><?php echo e($facture->statut); ?></td>
                                </tr>
                                <?php if($facture->statut == 'payé'): ?>
                                    <tr>
                                        <td class="col-md-9">Facture d<?php echo e($type); ?></td>
                                        <td class="col-md-3">
                                            <?php if($facture->nom_res != null): ?>
                                                <?php echo e($facture->Id_res); ?>

                                            <?php elseif($facture->nom_ope !=0): ?>
                                                <?php echo e($facture->id_ope); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="col-md-9">Date de payment</td>
                                        <td class="col-md-3"><?php echo e($facture->date_payment); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <tr style="color: #F81D2D;">
                                    <td class="text-right">
                                        <h4><strong>Total:</strong></h4>
                                    </td>
                                    <td class="text-left">
                                        <h4><strong> <?php echo e($facture->montant); ?> MAD</strong></h4>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div>
                            <div class="col-md-12">
                                <p><b>Date :</b> <?php echo e(date('d/m/Y')); ?></p> <br />
                                <p><b>Signature</b></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        window.addEventListener('load', function (){
                window.print();

            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/print/imprime_fact.blade.php ENDPATH**/ ?>