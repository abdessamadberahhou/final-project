

<?php $__env->startSection('section-1'); ?>
    <section class="container shadow my-5 py-4 rounded-2">
        <?php if($rs!=null): ?>
        <?php echo Form::open([ 'method'=>'POST', 'class'=>'form col-12']); ?>

        
        <div class="mx-auto w-100">
            <div class="row field-add_resident d-lg-felx d-md-flex">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center t-sm-1 text-xs-center">
                    <label for="nom" class="form-label">Nom</label>
                    <input type="text" class="form-control w-75 mx-auto" name="nom" value="<?php echo e($rs->Nom); ?>" disabled>
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label for="prenom" class="form-label" >Prénom</label>
                    <input type="text" class="form-control w-75 mx-auto" name="prenom" value="<?php echo e($rs->Prenom); ?>" disabled>
                </div>
            </div>
            <div class="row field-add_resident d-lg-felx pt-lg-3 d-md-flex">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="date_nai">Date de naissance</label>
                    <input type="date" class="form-control w-75 mx-auto" name="date_nai" value="<?php echo e($rs->Date_nai); ?>" disabled>
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="cin">CIN</label>
                    <input type="text" class="form-control w-75 mx-auto" name="CIN" value="<?php echo e($rs->CIN); ?>" disabled>
                </div>
            </div>
            <div class="row field-add_resident d-lg-felx pt-lg-3">
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="num_tele">Numéro de Téléphone</label>
                    <input type="text" class="form-control w-75 mx-auto" name="num_tele" value="<?php echo e($rs->num_tele); ?>" disabled>
                </div>
                <div class="col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="nb_pers">Nombre des personnes</label>
                    <input type="text" class="form-control w-75 mx-auto" name="nb_pers" value="<?php echo e($rs->nb_pers); ?>" disabled>
                </div>
            </div>
            <div class="row field-add_resident pt-lg-3">
                <div class="col-12 col-lg-6 col-add_resident col-resident1 ps-lg-5 pt-sm-3 text-sm-center">
                    <label class="form-label" for="adresse">Adresse</label>
                    <input type="text" class="form-select w-75 mx-auto" name="adresse" value="<?php echo e($rs->Nom); ?>" disabled>
                </div>
            </div>
            <div class="row field-add_resident mt-4">
                <div class="col-12 col-add_resident col-resident1 pt-sm-3 text-center">
                    <a href="/resident" class="text-primary btn border-primary">Retour</a>
                </div>
            </div>
        </div>
        
        <?php echo Form::close(); ?>

        <?php else: ?>
            <h1>Resident not found</h1>
        <?php endif; ?>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/resident/show.blade.php ENDPATH**/ ?>