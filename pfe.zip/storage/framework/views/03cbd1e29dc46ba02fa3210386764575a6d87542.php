<?php $__env->startSection('section-1'); ?>
    <div class="container shadow mt-5 p-5">
        <div class="row justify-content-around text-center">
            <div class="col-lg-4">
                <label for="type_amel" class="form-label">Type amelioration</label>
                <input type="text" class="form-control" value="<?php echo e($amelioration->type_amel); ?>" disabled>
            </div>
            <div class="col-lg-4">
                <label for="nom_bat" class="form-label">Batiment</label>
                <input type="text" class="form-control" value="<?php echo e($amelioration->batiment_amel); ?>" disabled>
            </div>
        </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-lg-4">
                <label for="type_amel" class="form-label">Date d'amelioration</label>
                <input type="date" class="form-control" name="date_ameli" value="<?php echo e($amelioration->date_ameli); ?>" disabled>
            </div>
            <div class="col-lg-4">
                <label for="montant" class="form-label">Montant</label>
                <input type="text" class="form-control" name="montant" value="<?php echo e($amelioration->montant_amel); ?>" disabled>
            </div>
        </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-lg-4">
                <label for="description" class="form-label">Description</label>
                <textarea type="text" class="form-control" name="description" disabled><?php echo e($amelioration->description_amel); ?></textarea>
            </div>
            <div class="col-lg-4"></div>
        </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-6">
                <a class="btn border-primary text-primary" href="/amelioration">retour</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/amel/show.blade.php ENDPATH**/ ?>