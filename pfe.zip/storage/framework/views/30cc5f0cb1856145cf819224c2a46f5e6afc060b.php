<?php $__env->startSection('section-1'); ?>
    <?php if($facture!=null ): ?>
        <?php echo Form::open(['action'=>['factureController@update',$facture->id],'method'=>'post']); ?>

        <input type="hidden" value="<?php echo e($facture->id); ?>" name="id">
        <div class="facture_payment container shadow mt-5 p-5">
            <div class="row justify-content-around text-center">
                <div class="col-lg-5">
                    <label for="num_recu" class="label-form">Num de reçu</label>
                    <input type="text" name="num_recu" id="num_recu" class="form-control" value="<?php echo e($facture->num_recu); ?>" disabled>
                </div>
                <div class="col-lg-5">
                    <label for="type_facture" class="label-form">Type facture</label>
                    <input type="text" class="form-control mx-auto" id="type_facture" name="type_facture" value="<?php echo e($facture->type_facture); ?>" disabled>
                </div>
            </div>
            <div class="row justify-content-around text-center mt-lg-4">
                <div class="col-lg-5">
                    <label for="reference_facture" class="label-form">Reference facture</label>
                    <input type="text" name="reference" id="reference_facture" class="form-control" value="<?php echo e($facture->reference_facture); ?>" >
                </div>
                <div class="col-lg-5">
                    <label for="date_ajout" class="label-form">Date d'ajout</label>
                    <input type="date" name="date_ajout" id="date_ajout" class="form-control" value="<?php echo e($facture->date_ajout); ?>">
                </div>
            </div>
            <div class="row justify-content-around text-center mt-lg-4">
                <div class="col-lg-5">
                    <label for="montant" class="label-form">Montant facture</label>
                    <input type="text" name="montant" id="montant" class="form-control" value="<?php echo e($facture->montant); ?>" >
                </div>
                <div class="col-lg-5">
                    <label for="batiment" class="label-form">Batiment</label>
                    <select class="form-control mx-auto" name="batiment" >
                        <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                <?php if("<?php echo e($facture->batiment); ?>" == "<?php echo e($bat->nom_bat); ?>"): ?>
                                selected="selected"
                                <?php endif; ?>
                                value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="row justify-content-around text-center mt-lg-4">
                <div class="col-lg-5">
                    <label for="id_resident" class="label-form">Id resident</label>
                    <input type="text" name="id_resident" id="id_resident" class="form-control " value="<?php echo e($facture->Id_res); ?>">
                </div>
                <div class="col-lg-5">
                    <label for="date_payment" class="label-form">Date de payment</label>
                    <input type="date" name="date_payment" id="date_payment" class="form-control" value="<?php echo e($facture->date_payment); ?>">
                </div>
            </div>
            <div class="row justify-content-around text-center mt-lg-4">
                <div class="col-lg-5">
                    <?php echo Form::hidden('_method','PUT'); ?>

                    <button class="btn border-success text-success btn-edit" type="submit">Modifier</button>
                    <a href="/facture" class="btn border-primary text-primary btn-consult">Revenir</a>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    <?php else: ?>
        <div class="aucun_resultat">
            <h3 class="text-center">Aucun resultat ou cette facture deja payee</h3>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
    <script>
        let fact = document.getElementById('type_facture');
        t = ['id_resident','cin_res'];
        for(let i = 0; i<t.length;i++){
            document.getElementById(t[i]).setAttribute("disabled","");
        }

        fact.addEventListener('change',()=>{
            resualt = String(fact.options[fact.selectedIndex].value);
            if(resualt == 'f_elec_res' || resualt == 'f_eau_res'){
                for(let i = 0; i<t.length;i++){
                    document.getElementById(t[i]).removeAttribute('disabled');
                }
            }
            else {
                for(let i = 0; i<t.length;i++){
                    document.getElementById(t[i]).setAttribute("disabled","");
                }
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/facture/edit.blade.php ENDPATH**/ ?>