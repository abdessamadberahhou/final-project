<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 p-5">
            <?php echo Form::open(['action' => '\App\Http\Controllers\factureController@store', 'method'=>'POST', 'class'=>'form col-12']); ?>

            <div class="mx-auto w-100">
                <div class="row field-add_resident d-lg-felx d-md-flex">


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center t-sm-1 text-xs-center">
                        <label for="type_facture" class="form-label">Type de facture</label>
                        <div class="d-flex justify-content-center align-items-center">
                            <select class="form-control w-75 " id="fact_type" name="type_facture">
                                <option value="">Choisir le type de facture </option>
                                <?php $__currentLoopData = $type_fact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->valeur_type); ?>"><?php echo e($type->valeur_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>



                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center t-sm-1 text-xs-center inter" id="inter">
                        <label for="nom-resident" class="form-label">Inter</label>
                        <div class="d-flex mx-auto justify-content-center align-items-center">
                            <select class="form-control w-75 test1" data-live-search="true" name="fact_type_sec" id="fact_type_1">
                                <option value="">Choisir le type Inter</option>
                                <?php $__currentLoopData = $type_fact_sec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact_sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($fact_sec->nom_type_sec); ?>"><?php echo e($fact_sec->type_facture_sec); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="border-primary"><i class="fa-solid fa-plus h4 mb-0 ms-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop2"></i></span>
                        </div>
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center inter_1 inter" id="inter_1">
                        <label for="reference" class="form-label" >Réference de facture</label>
                        <input type="text" class="form-control w-75 mx-auto" name="reference">
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center inter_2" id="inter_2">
                        <label for="resident" class="form-label" >Résident</label>
                        <div class="d-flex mx-auto justify-content-center align-items-center">
                            <select name="resident" id="resident" class="form-control w-75">
                                <option value="">Choisir le resident</option>
                                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($resident->Id_resident); ?>"><?php echo e($resident->Nom); ?> <?php echo e($resident->Prenom); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <a href="/resident/create" class="border-primary text-black"><i class="fa-solid fa-plus h4 mb-0 ms-2"></i></a></div>
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center inter_3" id="inter_3">
                        <label for="operateur" class="form-label" >Operateur</label>
                        <div class="d-flex mx-auto justify-content-center align-items-center">
                            <select name="operateur" id="operateur" class="form-control w-75">
                                <option value="">Choisir le resident</option>
                                <?php $__currentLoopData = $operateur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ope->id); ?>"><?php echo e($ope->nom_ope); ?> <?php echo e($ope->prenom_ope); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <a href="/resident/create" class="border-primary text-black"><i class="fa-solid fa-plus h4 mb-0 ms-2"></i></a></div>
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="date_ajout">Date d'ajout</label>
                        <input type="date" class="form-control w-75 mx-auto" name="date_ajout" value="<?php echo date('Y-m-d')?>">
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="montant">Montant</label>
                        <input type="text" class="form-control w-75 mx-auto" id="montant" name="montant">
                    </div>


                    <div class="mt-4 col-12 col-lg-6 col-add_resident ps-lg-5 pt-sm-3 text-sm-center">
                        <label class="form-label" for="batiment">Batiment</label>
                        <select class="form-control w-75 mx-auto" name="batiment" >
                            <?php $__currentLoopData = $bat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($batiment->nom_bat); ?>"><?php echo e($batiment->nom_bat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                </div>


                <div class="row">
                    <div class="row field-add_resident mt-4">
                        <div class="col-12 col-add_resident col-resident1 pt-sm-3 text-center">
                            <a href=""><button type="submit" class="btn border-success text-success">Ajouter</button></a>
                            <a href="/facture" class="text-primary btn border-primary">Retour</a>
                        </div>
                    </div>
                </div>
                <?php echo Form::close(); ?>

    </section>



                <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-center" id="staticBackdropLabel">Ajouter un type secondaire</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <?php echo Form::open(['action' => '\App\Http\Controllers\factureController@addSecType' ,'method'=>'get']); ?>

                                <div class="row text-center">
                                    <div class="col-6 mx-auto">
                                        <label for="valeur_type_sec" class="label-control">Valeur de Type</label>
                                        <input type="text" name="valeur_type_sec" id="valeur_type_sec" class="form-control mt-2" required>
                                    </div>
                                    <div class="col-6 mx-auto">
                                        <label for="nom_type_sec" class="label-control">Valeur de Type</label>
                                        <input type="text" name="nom_type_sec" id="nom_type_sec" class="form-control mt-2" required>
                                    </div>
                                </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn text-secondary border-secondary" data-bs-dismiss="modal">Close</button>
                                    <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#staticBackdrop4" class="btn border-danger text-danger">Supprimer</a>
                                    <a href="/f/createe" class=""><button class="btn border-primary text-primary" type="submit">Ajouter</button></a>
                                </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>





                <div class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-center" id="staticBackdropLabel">Supprimmer un type</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row text-center">
                                    <select class="form-control w-75 mx-auto" id="del_type" name="">
                                        <option value="">Choisir le type de facture </option>
                                        <?php $__currentLoopData = $type_fact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type->valeur_type); ?>" data-id="<?php echo e($type->id); ?>"><?php echo e($type->valeur_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn text-secondary border-secondary" data-bs-dismiss="modal">Close</button>
                                <a href="#" class="deletebtn btn border-danger text-danger">supprimer</a>
                            </div>
                        </div>
                    </div>
                </div>





    <div class="modal fade" id="staticBackdrop4" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="staticBackdropLabel">Supprimmer un type secondaire</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row text-center">
                        <select class="form-control w-75 mx-auto" id="del_type_sec" name="">
                            <option value="">Choisir le type de facture </option>
                            <?php $__currentLoopData = $type_fact_sec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact_sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fact_sec->nom_type_sec); ?>" data-id="<?php echo e($fact_sec->id); ?>"><?php echo e($fact_sec->type_facture_sec); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn text-secondary border-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="#" class="deletebtnsec btn border-danger text-danger">supprimer</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>
        let fer = document.getElementById('fact_type_1');
        let fact = document.getElementById('fact_type');
        let    t = document.getElementsByClassName('inter');
        let fact_1 = document.getElementById('fact_type_1');
        let    tab = document.getElementById('inter_1');
        let    tab2 = document.getElementById('inter_2');
        let del = document.getElementById('del');
        let delType = document.getElementById('del_type');
        let delTypeSec = document.getElementById('del_type_sec');
        let id;
        let ids;
        let montant = document.getElementById('montant');
        let ope = document.getElementById("inter_3");

        // debut suppression des types principales
        delType.addEventListener('change', ()=>{
            let resualt1 = delType.options[delType.selectedIndex];
            id = resualt1.getAttribute('data-id');
        });
        $('.deletebtn').click(function (){
            swal({
                title: "voulez vou vraiment supprimer ce type",
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/f/del_type/"+id;
                    }
                });
        });
        // fin suppression des types principales


        // debut suppression des types secondaires
        delTypeSec.addEventListener('change', ()=>{
            let resualt2 = delTypeSec.options[delTypeSec.selectedIndex];
            ids = resualt2.getAttribute('data-id');
            $('.deletebtnsec').click(function (){
                swal({
                    title: "voulez vou vraiment supprimer ce type",
                    text: "",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                    .then((willDelete) => {
                        if (willDelete) {
                            window.location = "/f/del_type_sec/"+ids;
                        }
                    });
            });
        });
        // fin suppression des types secondaires


        //Debut jQuery de les types secondaires (afficher les inputs des types secondaires)
        for(let i = 0;i<t.length;i++){
            t[i].style.display = 'none';
        }
        ope.style.display = "none";
        fact.addEventListener('change',()=>{
            resualt = String(fact.options[fact.selectedIndex].value);
            console.log(resualt);
            choixType(resualt);
        });
        fact_1.addEventListener('change',()=>{
            resualt_1 = String(fact_1.options[fact_1.selectedIndex].value);
            if(resualt_1 == "f_eau" || resualt_1 == "f_elec"){
                $(ope).hide(150);
                $(tab).show(150);
            }
            else if(resualt_1 == "f_ope"){
                $(tab).hide(150);
                $(ope).show(150);
            }
            else {
                $(ope).hide(150);
                $(tab).hide(150);
            }
        });
        //Fin jQuery de les types secondaires (afficher les inputs des types secondaires)



        window.addEventListener('load',()=>{
            resualt = String(fact.options[fact.selectedIndex].value);
            choixType(resualt);
        });



        function choixType (resualt){
            if(resualt == 'Facture de dépense'){
                $(tab2).hide(150);
                for(let i = 0;i<t.length;i++){
                    $(t[i]).show(150);
                }
                tab.style.display = 'none';
                montant.value = '';
            }
            else if(resualt == "Facture d'entrer"){
                for(let i = 0;i<t.length;i++){
                    $(t[i]).hide(150);
                }
                $(tab2).show(150);
                montant.value = 120;
            }
            else {
                $(tab2).hide(150);
                for(let i = 0;i<t.length;i++){
                    $(t[i]).hide(150);
                }
                montant.value = '';
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/facture/create.blade.php ENDPATH**/ ?>