<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 py-3">
        <?php if($fac!=null): ?>
            <div class="all pt-5">
                <div class="row text-center mb-5">
                    <h2><b>Information sur la facture</b></h2>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Id de facture <span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->id); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Type de facture <span>:</span> </dt>
                        <dd class="col">
                            <?php echo e($fac->type_facture); ?>

                            <?php if($fac->type_fact_sec != 0): ?>
                                /<?php echo e($fac->type_fact_sec); ?>

                            <?php endif; ?>
                        </dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Réference de fatcture<span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->reference_facture); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Date d'ajout<span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->date_ajout); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Montant <span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->montant); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Batiment <span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->batiment); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Statut <span>:</span> </dt>
                        <dd class="col"><b><?php echo e($fac->statut); ?></b></dd>
                    </dl>
                </div>
                <?php if($fac->statut == 'payé'): ?>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Facture d<?php echo e($type); ?> <span>:</span> </dt>
                        <dd class="col">
                            <?php if($fac->nom_res != null): ?>
                                <?php echo e($fac->nom_res); ?>

                            <?php elseif($fac->nom_ope !=0): ?>
                                <?php echo e($fac->nom_ope); ?>

                            <?php endif; ?>
                        </dd>
                    </dl>
                </div>
                    <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">id d<?php echo e($type); ?> <span>:</span> </dt>
                        <dd class="col">
                            <?php if($fac->nom_res != null): ?>
                                <?php echo e($fac->Id_res); ?>

                            <?php elseif($fac->nom_ope !=0): ?>
                                <?php echo e($fac->id_ope); ?>

                            <?php endif; ?>
                        </dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">date de payment <span>:</span> </dt>
                        <dd class="col"><?php echo e($fac->date_payment); ?></dd>
                    </dl>
                </div>
            </div>
            <div class="retour text-center">
                <a href="/facture" class="btn border-primary text-primary btn-add">Retour</a>
            </div>
        <?php endif; ?>
        <?php else: ?>
            <div class="text-center pt-4">
                <h2><b>Aucun resultat</b></h2>
            </div>
                <div class="retour text-center">
                    <a href="/facture" class="btn border-primary text-primary btn-add">Retour</a>
                </div>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/facture/show.blade.php ENDPATH**/ ?>