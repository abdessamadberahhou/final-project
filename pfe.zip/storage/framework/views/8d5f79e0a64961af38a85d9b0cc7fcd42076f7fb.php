<?php $__env->startSection('section-1'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="p-1 shadow container mt-5">
        <table class="table">
            <tr>
                <?php echo Form::open(['action'=>'\App\Http\Controllers\ameliorationController@search', 'method'=>'post']); ?>

                <th class="col-1">
                    <input type="text" class="form-control" placeholder="Id" name="id_amel">
                </th>
                <th class="col-2">
                    <select name="type_amel" id="" class="form-select">
                        <option value="">Tout</option>
                        <?php $__currentLoopData = $type_amel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->type_amel); ?>"><?php echo e($type->type_amel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </th>
                <th>
                    <select name="batiment" id="" class="form-select">
                        <option value="">Tout</option>
                        <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </th>
                <th class="col-2">

                </th>
                <th></th>
                <th></th>
                <th><button class="btn border-primary text-primary" type="submit">Rechercher</button></th>
                <?php echo Form::close(); ?>

            </tr>
            <tr>
                <th>Id</th>
                <th>Type Amelioration</th>
                <th>Batiment</th>
                <th>Date d'amelioration</th>
                <th>Montant</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php if(count($amelioration)>0): ?>
                <?php $__currentLoopData = $amelioration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($amel->id_amel); ?></td>
                        <td><?php echo e($amel->type_amel); ?></td>
                        <td><?php echo e($amel->batiment_amel); ?></td>
                        <td><?php echo e($amel->date_amel); ?></td>
                        <td><?php echo e($amel->montant_amel); ?></td>
                        <td><?php echo e($amel->description_amel); ?></td>
                        <td>
                            <a href="/amelioration/<?php echo e($amel->id_amel); ?>" class="btn btn-consult border-primary text-primary"><i class="bi bi-eye"></i></a>
                            <a href="/amelioration/<?php echo e($amel->id_amel); ?>/edit" class="btn btn-edit border-success text-success"><i class="bi bi-pencil-square"></i></a>
                            <a class="btn-delete deletebtn btn border-danger text-danger" data-id="<?php echo e($amel->id_amel); ?>" href="#"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
        </table>
        <div class="no-records text-center ">
            <p><b>Aucun resultat</b></p>
        </div>
        <?php endif; ?>
    </div>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>

        $('.deletebtn').click(function (){
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vou vraiment supprimer cette amelioration",
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/amelioration/delete/"+id;
                    }
                });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/amel/search.blade.php ENDPATH**/ ?>