<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/payment.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-1'); ?>
        <div class="container cont-1 mt-4 p-4 w-75">
            <?php if($total!=null && $total->statut != 'payé'): ?>
            <?php echo Form::open(['action'=>['checkoutController@confirm', $total->montant],'method'=>'post','id'=>'payment-form']); ?>

                <input type="hidden" value="<?php echo e($total->id); ?>" name="id">
                <?php echo e(csrf_field()); ?>

                <div class="bills_price text-center">
                    <h3><b><?php echo e($total->montant); ?> DH</b></h3>
                    <input type="hidden" name="montant" value="<?php echo e($total->montant); ?>">
                </div>
                <div class="inputBox">
                    <span>Nom dans le cart</span>
                    <input type="text" maxlength="16" id="name_on_card" name="name">
                </div>
                <div class="inputBox">
                    <span>Adresse</span>
                    <input type="text" class="" id="address" name="address">
                </div>
                <div class="form-row" >
                    <label for="card-element">
                        <span>Credit or debit card</span>
                    </label>
                    <div id="card-element">
                        <!-- A Stripe Element will be inserted here. -->
                    </div>

                    <!-- Used to display Element errors. -->
                    <div id="card-errors" role="alert"></div>
                </div>
                <button class="submit-btn">Payer</button>
            <?php echo Form::close(); ?>

            <?php else: ?>
            <div class="aucun_resultat text-center p-4 mt-5">
                <h3><b>aucun resultat ou cette facture deja payee</b></h3>
            </div>
        </div>
        <?php endif; ?>
        <?php $__env->startSection('extra-js'); ?>

        <script src="https://js.stripe.com/v3/"></script>

        <script>
            (function(){
                var data = {
                    name: document.getElementById('name_on_card').value
                }
                // Create a Stripe client
                var stripe = Stripe('<?php echo e(config('services.stripe.key')); ?>');

                // Create an instance of Elements
                var elements = stripe.elements();

                // Custom styling can be passed to options when creating an Element.
                // (Note that this demo uses a wider set of styles than the guide below.)
                var style = {
                    base: {
                        color: '#32325d',
                        lineHeight: '18px',
                        fontFamily: '"Roboto", Helvetica Neue", Helvetica, sans-serif',
                        fontSmoothing: 'antialiased',
                        fontSize: '16px',
                        '::placeholder': {
                            color: '#aab7c4'
                        }
                    },
                    invalid: {
                        color: '#fa755a',
                        iconColor: '#fa755a'
                    }
                };

                // Create an instance of the card Element

                var card = elements.create('card', {
                    style: style,
                    hidePostalCode: true
                });

                // Add an instance of the card Element into the `card-element` <div>
                card.mount('#card-element');

                // Handle real-time validation errors from the card Element.
                card.addEventListener('change', function(event) {
                    var displayError = document.getElementById('card-errors');
                    if (event.error) {
                        displayError.textContent = event.error.message;
                    } else {
                        displayError.textContent = '';
                    }
                });

                // Handle form submission
                var form = document.getElementById('payment-form');
                form.addEventListener('submit', function(event) {
                    event.preventDefault();


                    stripe.createToken(card, data).then(function(result) {
                        if (result.error) {
                            // Inform the user if there was an error
                            var errorElement = document.getElementById('card-errors');
                            errorElement.textContent = result.error.message;
                        } else {
                            // Send the token to your server
                            stripeTokenHandler(result.token);
                        }
                    });
                });

                function stripeTokenHandler(token) {
                    // Insert the token ID into the form so it gets submitted to the server
                    var form = document.getElementById('payment-form');
                    var hiddenInput = document.createElement('input');
                    hiddenInput.setAttribute('type', 'hidden');
                    hiddenInput.setAttribute('name', 'stripeToken');
                    hiddenInput.setAttribute('value', token.id);
                    form.appendChild(hiddenInput);

                    // Submit the form
                    form.submit();
                }


            })();
        </script>
        <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/payment/facture/facture_payment_pay.blade.php ENDPATH**/ ?>