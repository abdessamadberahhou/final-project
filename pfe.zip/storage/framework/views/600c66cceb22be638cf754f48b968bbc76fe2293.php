<?php $__env->startSection('section-1'); ?>
    <div class="container shadow text-center p-4 mt-4">
        <a href="/batiment/create"><button class="btn border-primary text-primary">Ajouter</button></a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>
    <div class="container shadow mt-5">
        <table class="table ">
            <?php echo Form::open(['action' => '\App\Http\Controllers\batimentController@search', 'method'=>'GET']); ?>

            <tr>
                <th class="col-lg-1">
                    <input type="text" class="form-control text-center filter-input" name="id"
                           placeholder="id" data-column="0">
                </th>
                <th class="col-lg-2">
                    <input type="text" class="form-control text-center filter-input" name="nb_apt"
                           placeholder="nb apt" data-column="1">
                </th>
                <th class="col-lg-2">
                    <input type="text" class="form-control text-center filter-input" name="adresse"
                           placeholder="adresse" data-column="2">
                </th>
                <th>

                </th>
                <th>

                </th>
                <th class="col-lg-2">
                    <input type="text" class="form-control text-center filter-input" name="femme_men"
                           placeholder="femme de menage" data-column="2">
                </th>
                <th >

                </th>
                <th class="text-center">
                    <button type="submit" class="btn btn-success">Afficher</button>
                </th>
            </tr>
            <?php echo Form::close(); ?>

            <tr>
                <th>id</th>
                <th>nb apt</th>
                <th>adresse</th>
                <th>nb hab</th>
                <th>date Cons</th>
                <th>femme menage</th>
                <th>nom bat</th>
                <th class="text-center">Action</th>
            </tr>

            <?php if(count($batiment)>0): ?>
                <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($bat->id); ?></td>
                        <td><?php echo e($bat->nb_apt); ?></td>
                        <td><?php echo e($bat->adresse); ?></td>
                        <td><?php echo e($bat->nb_hab); ?></td>
                        <td><?php echo e($bat->date_cons); ?></td>
                        <td><?php echo e($bat->femme_men); ?></td>
                        <td><?php echo e($bat->nom_bat); ?></td>
                        <td class="text-center">
                            <a href="/batiment/<?php echo e($bat->id); ?>"><button class="btn border-primary text-primary btn-consult"><i class="bi bi-eye"></i></button></a>
                            <a href="/batiment/<?php echo e($bat->id); ?>/edit"><button class="btn border-success text-success btn-edit"><i class="bi bi-pencil-square"></i></button></a>
                            <a href="#" data-id="<?php echo e($bat->id); ?>" class="deletebtn"><button class="btn border-danger text-danger btn-delete"><i class="bi bi-trash3"></i></button></a>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php else: ?>
            <h4>no resualt found</h4>
        <?php endif; ?>

    </div>
    <script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script>
        $('.deletebtn').click(function (){
            var id = $(this).attr('data-id');
            swal({
                title: "voulez vou vraiment supprimer "+id,
                text: "",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/batiment/delete/"+id;
                    }
                });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/batiment/search.blade.php ENDPATH**/ ?>