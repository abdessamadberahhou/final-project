<?php $__env->startSection('section-1'); ?>
    <section class="container shadow mt-5 p-5">
        <?php if($batiment!=null): ?>
            <div class="all pt-5">
                <div class="row text-center mb-5">
                    <h2><b>Information sur le batiment</b></h2>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Nombre d'appartements <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->nb_apt); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Adresse <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->adresse); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Nombre d'habitents <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->nb_hab); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Date de construction <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->date_cons); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Femme de menage <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->femme_men); ?></dd>
                    </dl>
                </div>
                <div class="row w-75 mx-auto">
                    <dl class="col-12 d-flex">
                        <dt class="col d-flex justify-content-between pe-5">Batiment <span>:</span> </dt>
                        <dd class="col"><?php echo e($batiment->nom_bat); ?></dd>
                    </dl>
                </div>
            </div>
            <div class="retour text-center">
                <a href="/batiment" class="btn border-primary text-primary btn-add">Retour</a>
            </div>
        <?php else: ?>
            <div class="text-center pt-4">
                <h2><b>Aucun resultat</b></h2>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-2'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe\resources\views/batiment/show.blade.php ENDPATH**/ ?>