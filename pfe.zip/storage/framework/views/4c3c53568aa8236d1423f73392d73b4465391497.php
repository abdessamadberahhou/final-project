<?php $__env->startSection('section-1'); ?>
    <div class="container shadow mt-5 p-5">
        <?php echo Form::open(['action' => '\App\Http\Controllers\ameliorationController@store','method'=>'POST']); ?>

            <div class="row justify-content-around text-center">
                <div class="col-lg-4">
                    <label for="type_amel" class="form-label">Type amelioration</label>
                    <select name="type_amel" id="" class="form-select">
                        <option value="damage">Damage</option>
                        <option value="changement">Changement</option>
                        <option value="mise a jour">Mise à jour</option>
                    </select>
                </div>
                <div class="col-lg-4">
                    <label for="nom_bat" class="form-label">Batiment</label>
                    <?php if(count($batiment)>0): ?>
                        <select name="batiment" id="" class="form-select">
                            <?php $__currentLoopData = $batiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bat->nom_bat); ?>"><?php echo e($bat->nom_bat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php else: ?>
                                <option value="">Error</option>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row justify-content-around text-center mt-4">
                <div class="col-lg-4">
                    <label for="type_amel" class="form-label">Date d'amelioration</label>
                    <input type="date" class="form-control" name="date_ameli" value="<?php echo date('Y-m-d') ?>">
                </div>
                <div class="col-lg-4">
                    <label for="montant" class="form-label">Montant</label>
                    <input type="text" class="form-control" name="montant">
                </div>
            </div>
            <div class="row justify-content-around text-center mt-4">
                <div class="col-lg-4">
                    <label for="description" class="form-label">Description</label>
                    <textarea type="text" class="form-control" name="description"></textarea>
                </div>
                <div class="col-lg-4"></div>
            </div>
        <div class="row justify-content-around text-center mt-4">
            <div class="col-6">
                <button class="btn border-primary text-primary">Ajouter</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/amel/create.blade.php ENDPATH**/ ?>