<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('icons-1.8.1/font/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/all.css')); ?>">

</head>
<body>
    <div>
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(Auth::user()): ?>
            <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="home-section">
                    <?php echo $__env->make('navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <section class="section-1">
                        <?php echo $__env->yieldContent('content'); ?>
                        <?php echo $__env->yieldContent('section-1'); ?>
                    </section>
                    <section class="section-2">
                        <?php echo $__env->yieldContent('section-2'); ?>
                    </section>
                </div>
        <?php else: ?>
        <div class="home-section" style="left: 0; width: 100%">
            <?php echo $__env->make('navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="section-1">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->yieldContent('section-1'); ?>
            </section>
            <section class="section-2">
                <?php echo $__env->yieldContent('section-2'); ?>
            </section>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pfe-abdou\resources\views/layouts/app.blade.php ENDPATH**/ ?>