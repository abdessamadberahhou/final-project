@extends('layouts.app')

@section('section-1')
    <div class="container shadow mt-5 p-5">
        <div class="row mx-auto justify-content-around">
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-lg-0 mt-sm-3 mt-3">
                <div class="small-box shadow rounded d-flex align-items-center" style="background: lightgray">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-people"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des résidents</span><br>
                            <span>{{$residents}}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-lg-0 mt-sm-3 mt-3">

                <div class="small-box shadow rounded d-flex align-items-center" style="background: #63c7ff; .small-box{background: #3b76ef;>
                    }">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-circle-dollar"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des factures mois</span><br>
                            <span>{{$motant_factures}} Dh</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-lg-0 mt-sm-3 mt-3">

                <div class="small-box shadow rounded d-flex align-items-center" style="background: #a66dd4">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-family-dress"></i>
                        <div class="info ms-2 d-block">
                            <span>Total de résidents (tout)</span><br>
                            <span>{{$total_residents}}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-lg-0 mt-sm-3 mt-3">
                <div class="small-box  shadow rounded d-flex align-items-center" style="background: #6dd4b1">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-money-bills"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des factures (entrées)</span><br>
                            <span>{{$sum_e}} MAD</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mx-auto">
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-sm-3 mt-3 mx-sm-auto mx-lg-0">
                <div class="small-box  shadow rounded d-flex align-items-center" style="background: #0bd98b">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-file-invoice-dollar"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des factures (dépense)</span><br>
                            <span>{{$sum_d}} MAD</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-sm-3 mt-3 mx-sm-auto mx-lg-0">
                <div class="small-box  shadow rounded d-flex align-items-center" style="background: #a9eefc">
                    <div class="card-content d-flex align-items-center justify-content-between mx-4">
                        <i class="fa-solid fa-money-bills"></i>
                        <div class="info ms-2 d-block ">
                            <span>Total brut restant</span><br>
                            <span id="total_brut"><b>{{$sum_e - $sum_d}} MAD</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-sm-3 mt-3 mx-sm-auto mx-lg-0">
                <div class="small-box  shadow rounded d-flex align-items-center" style="background: rgba(172,11,217,0.6)">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-file-invoice-dollar"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des factures (payé)</span><br>
                            <span>{{$sum_pay}}</span><br>
                            <span><b>Montant:</b> <b><span id="pay">{{$sum_npay_p}} MAD</span></b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-9 col-9 mt-md-4 mt-sm-3 mt-3 mx-sm-auto mx-lg-0">
                <div class="small-box  shadow rounded d-flex align-items-center" style="background: rgba(11,131,217,0.6)">
                    <div class="card-content d-flex align-items-center mx-auto">
                        <i class="fa-solid fa-file-invoice-dollar"></i>
                        <div class="info ms-2 d-block">
                            <span>Total des factures (non payé)</span><br>
                            <span>{{$sum_npay}}</span><br>
                            <span><b>Montant:</b> <b><span id="n_pay">{{$sum_npay_np}} MAD</span></b></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="charts container mt-5 justify-content-between">
            <div class="row d-lg-flex">
                <div class="col-lg-6 ">
                    <b><h5 class="text-center">Nombre de résidents</h5></b>
                    <h6 class="text-center"><b>{{$sum_res}}</b></h6>
                    <canvas class="chart-1" id="chart-1">

                    </canvas>
                </div>
                <div class="col-lg-6">
                    <b>
                        <h5 class="text-center">Nombre de résidents (Total)</h5>
                        <h6 class="text-center"><b>{{$sum_total}}</b></h6>
                    </b>
                    <canvas class="chart-2" id="chart-2">

                    </canvas>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-6 ms-lg-3">
                    <b>
                        <h5 class="text-center">Montant global des factures</h5>
                        <h6 class="text-center"><b>{{$res_fact}}MAD</b></h6>
                    </b>
                    <canvas class="chart-3" id="chart-3">

                    </canvas>
                </div>
            </div>
        </div>
    </div>


@endsection
@section('section-2')

@endsection
@section('extra-js')
    <script src="{{asset('js/chart.js')}}"></script>
    <script>
        let firstChart = document.getElementById('chart-1').getContext('2d');
        let residentChart = new Chart(firstChart,{
            type:'bar',
            data:{
                labels:['Jan', 'Fev', 'Mars','Avril','Mai','June','Juil','Aout','Sep', 'Oct', 'Nou', 'Dec'],
                datasets:[{
                    label:'Résidents',
                    data:[
                        @for($i = 0;$i<count($mon);$i++)
                            {{$mon[$i]}},
                        @endfor
                    ],
                    backgroundColor:'lightgray',
                }]
            },
            options:{
                plugins:{
                    legend:{
                        display: true,
                    }
                }
            }
        });




        let secondChart = document.getElementById('chart-2').getContext('2d');
        let totalResident = new Chart(secondChart,{
            type:'line',
            data:{
                labels:['Jan', 'Fev', 'Mars','Avril','Mai','June','Juil','Aout','Sep', 'Oct', 'Nou', 'Dec'],
                datasets:[{
                    label:'Résidents (total)',
                    data:[
                        @for($i = 0;$i<count($mon);$i++)
                            {{$mon_all[$i]}},
                        @endfor
                    ],
                    backgroundColor:'#a66dd4',
                }]
            },
            options:{
                plugins:{
                    legend:{
                        display: true,
                    }
                }
            }
        });
        let thirdChart = document.getElementById('chart-3').getContext('2d');
        let factChart = new Chart(thirdChart,{
            type:'line',
            data:{
                labels:['Jan', 'Fev', 'Mars','Avril','Mai','June','Juil','Aout','Sep', 'Oct', 'Nou', 'Dec'],
                datasets:[{
                    label:'Résidents (total)',
                    data:[
                        @for($i = 0;$i<count($mon);$i++)
                            {{$mon_fact[$i]}},
                        @endfor
                    ],
                    backgroundColor:'#63c7ff',
                }]
            },
            options:{
                plugins:{
                    legend:{
                        display: true,
                    }
                }
            }
        });
    </script>
    <script>
        let total_bru = document.getElementById('total_brut');
        let npay = document.getElementById('n_pay');
        if(parseFloat(total_bru.innerText) < 0){
            total_bru.style.color = 'red';
        }
        if(parseFloat(npay.innerHTML)>0){
            npay.style.color = "red";
        }
    </script>
@endsection
