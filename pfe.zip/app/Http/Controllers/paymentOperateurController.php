<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class paymentOperateurController extends Controller
{
    public function index(){

        return view('payment.operateur.operateur_payment',[
            'invoices' => Auth::user()->invoices(),
        ]);
    }
}
