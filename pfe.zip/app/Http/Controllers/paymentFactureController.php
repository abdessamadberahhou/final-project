<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Resident;
use App\Models\Batiment;
use App\Models\FactureType;
use App\Models\Facture;
use Illuminate\Support\Facades\DB;
use Omnipay\Omnipay;
use Stripe\Stripe;
use Stripe\Charge;

class paymentFactureController extends Controller
{
    public $gateway;
    public $completePaymentUrl;
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('isAdmin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $facture = Facture::all();
        return view('payment.facture.facture_payment')->with('facture',$facture);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $facture = Facture::find($id);
        return view('payment.facture.facture_payment_show')->with('facture',$facture);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $facture = Facture::find($id);
        $batiment = Batiment::all();
        $allfac = FactureType::all();
        return view('payment.facture.facture_payment_edit')
            ->with('batiment',$batiment)
            ->with('allfac',$allfac)
            ->with('facture',$facture);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'type_facture'=>'required',
            'reference_facture'=>'required',
            'date_ajout'=>'required',
            'montant_facture'=>'required',
            'batiment'=>'required',
            'statut'=>'required'
        ]);
        $facture = Facture::find($id);
        $facture->type_facture = $request->input('type_facture');
        $facture->reference_facture = $request->input('reference_facture');
        $facture->date_ajout = $request->input('date_ajout');
        $facture->montant = $request->input('montant_facture');
        if (!empty($request->input('id_resident'))){
            $facture->Id_res = $request->input('id_resident');
        }
        if (!empty($request->input('date_payment'))){
            $facture->date_payment = $request->input('date_payment');
        }
        if (!empty($request->input('num_recu'))){
            $facture->num_recu = $request->input('num_recu');
        }
        $facture->batiment = $request->input('batiment');
        $facture->statut = $request->input('statut');
        $facture->save();
        return redirect('/payment/facture')->with('success','facture modifiee avec succe');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $facture = Facture::find($id);
        $facture->delete();
        return redirect('/payment/facture')->with('success','facture supprime avec succe');
    }


}
