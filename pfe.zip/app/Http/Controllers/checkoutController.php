<?php

namespace App\Http\Controllers;

use App\Models\Facture;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Stripe\Stripe;
use Laravel\Cashier\Cashier;
use Illuminate\Http\Request;
use Carbon\Carbon;

class checkoutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('isAdmin');
    }

    public function pay(Request $request, $id){
        $total = Facture::find($id);
        return view('payment.facture.facture_payment_pay')->with('total',$total);
    }
    public function confirm(Request $request)
    {

        $stripe = \Stripe\Stripe::setApiKey('sk_test_51KYvm9FfFSDeOrIUtzCsdRyDix8OjMsnultVI1vHuNFbX9zJlQsaSAcXZij5JQoZcjXUbcKQmV009MU6kHxTtibh00hRW1zqPa');
        $facture = Facture::find($request->input('id'));
        $facture->statut = 'payé';
        $facture->date_payment = date('Y-m-d');
        $facture->num_recu = 'recu-'.$facture->reference_facture;
        $facture->save();
        $token = $_POST['stripeToken'];
        $charge = \Stripe\Charge::create([
            'amount' => $request->input('montant')*100,
            'currency' => 'mad',
            'description' => 'Example charge',
            'source' => $token,
            'metadata'=>[
                'name'=> $request->input('name'),
                'address'=> $request->input('address')
            ]
        ]);
        return redirect('/payment/facture')->with('success','Facture payee avec succee');
    }
}
